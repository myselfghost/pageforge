﻿(function () {
  var APP = 'site-alpha', VER = 'v1';
  function render() {
    var baseTag = document.querySelector('base');
    document.getElementById('view').textContent =
      'app:      ' + APP + '\n' +
      'version:  ' + VER + '\n' +
      'base:     ' + (baseTag ? baseTag.getAttribute('href') : '(none)') + '\n' +
      'path:     ' + location.pathname + '\n' +
      'hash:     ' + (location.hash || '(none)') + '\n' +
      'time:     ' + new Date().toISOString();
  }
  window.addEventListener('hashchange', render);
  render();
})();